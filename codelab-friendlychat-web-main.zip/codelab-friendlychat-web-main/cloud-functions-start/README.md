# Firebase SDK for Cloud Functions Codelab - Start code

This folder contains the start code of the [Firebase SDK for Cloud Functions Codelab](https://codelabs.developers.google.com/codelabs/firebase-cloud-functions/).

If you'd like to jump directly to the end and see the finished code head to the [cloud-functions](../cloud-functions) directory.
